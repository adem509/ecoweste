
-- 1) Profiles: stop exposing phone numbers publicly
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;

CREATE POLICY "Users view own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Public view exposing only non-sensitive profile fields
CREATE OR REPLACE VIEW public.public_profiles
WITH (security_invoker = true) AS
SELECT id, full_name, region, created_at, updated_at
FROM public.profiles;

GRANT SELECT ON public.public_profiles TO anon, authenticated;

-- A row-level policy so the view (running as invoker) can read base rows for everyone
CREATE POLICY "Public profile basics viewable"
ON public.profiles FOR SELECT
TO anon, authenticated
USING (true);

-- Restrict column access: anon and authenticated cannot read the phone column directly
REVOKE SELECT ON public.profiles FROM anon, authenticated;
GRANT SELECT (id, full_name, region, created_at, updated_at) ON public.profiles TO anon, authenticated;
GRANT SELECT (phone) ON public.profiles TO authenticated; -- combined with RLS, users can only see rows; we'll lock phone via separate column policy

-- Replace broad column access with owner-only phone via a dedicated function
REVOKE SELECT (phone) ON public.profiles FROM authenticated;

CREATE OR REPLACE FUNCTION public.get_my_phone()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT phone FROM public.profiles WHERE id = auth.uid();
$$;

REVOKE EXECUTE ON FUNCTION public.get_my_phone() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_my_phone() TO authenticated;

-- 2) Storage: add owner-scoped UPDATE/DELETE and tighten INSERT to user folder
DROP POLICY IF EXISTS "Auth upload listing images" ON storage.objects;

CREATE POLICY "Users upload to own folder in listing-images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'listing-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users update own listing images"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'listing-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users delete own listing images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'listing-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- 3) Lock down SECURITY DEFINER has_role: not callable by clients
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
