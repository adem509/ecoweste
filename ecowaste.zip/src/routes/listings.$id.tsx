import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, MapPin, Package, Heart, Star, ArrowLeft, CreditCard, Banknote } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CATEGORY_LABELS, type Listing } from "@/components/ListingCard";
import { WILAYAS, calcDeliveryFee } from "@/lib/algeria";
import { createChargilyCheckout } from "@/lib/chargily.functions";

export const Route = createFileRoute("/listings/$id")({
  head: () => ({ meta: [{ title: "تفاصيل العرض | ECOWASTE" }] }),
  component: ListingDetailPage,
});

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer_id: string;
}

function ListingDetailPage() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [qty, setQty] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [deliveryMethod, setDeliveryMethod] = useState<"pickup" | "delivery">("pickup");
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "chargily">("cod");
  const [wilaya, setWilaya] = useState("");
  const [address, setAddress] = useState("");
  const chargilyCheckout = useServerFn(createChargilyCheckout);

  const { data: listing, isLoading } = useQuery({
    queryKey: ["listing", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("listings").select("*").eq("id", id).single();
      if (error) throw error;
      return data as Listing & { seller_id: string };
    },
  });

  const { data: reviews } = useQuery({
    queryKey: ["reviews", listing?.seller_id],
    enabled: !!listing,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reviews").select("*").eq("seller_id", listing!.seller_id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Review[];
    },
  });

  const { data: fav } = useQuery({
    queryKey: ["fav", id, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("favorites").select("id").eq("user_id", user!.id).eq("listing_id", id).maybeSingle();
      return !!data;
    },
  });

  const toggleFav = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("auth");
      if (fav) {
        await supabase.from("favorites").delete().eq("user_id", user.id).eq("listing_id", id);
      } else {
        await supabase.from("favorites").insert({ user_id: user.id, listing_id: id });
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["fav", id] }),
  });

  const reserve = useMutation({
    mutationFn: async () => {
      if (!user || !listing) throw new Error("auth");
      const quantity = Number(qty);
      if (!quantity || quantity <= 0) throw new Error("أدخل كمية صحيحة");
      if (quantity > listing.quantity_kg) throw new Error("الكمية أكبر من المتاح");
      if (!phone.trim()) throw new Error("أدخل رقم الهاتف");
      if (deliveryMethod === "delivery") {
        if (!wilaya) throw new Error("اختر ولاية التوصيل");
        if (!address.trim()) throw new Error("أدخل عنوان التوصيل");
      }
      const unit = listing.price_dzd / listing.quantity_kg;
      const subtotal = Math.round(unit * quantity);
      const fee = deliveryMethod === "delivery" ? calcDeliveryFee(wilaya, quantity) : 0;
      const total = subtotal + fee;
      const { data: inserted, error } = await supabase.from("orders").insert({
        listing_id: listing.id,
        buyer_id: user.id,
        seller_id: listing.seller_id,
        quantity_kg: quantity,
        total_dzd: total,
        buyer_phone: phone.trim(),
        buyer_note: note.trim() || null,
        delivery_method: deliveryMethod,
        delivery_wilaya: deliveryMethod === "delivery" ? wilaya : null,
        delivery_address: deliveryMethod === "delivery" ? address.trim() : null,
        delivery_fee_dzd: fee,
        payment_method: paymentMethod,
      }).select("id").single();
      if (error) throw error;
      return { orderId: inserted.id, total, method: paymentMethod };
    },
    onSuccess: async ({ orderId, total, method }) => {
      if (method === "chargily" && total > 0) {
        try {
          toast.info("جارٍ تحويلك لبوابة الدفع...");
          const { checkout_url } = await chargilyCheckout({ data: { order_id: orderId } });
          window.location.href = checkout_url;
          return;
        } catch (e) {
          const msg = e instanceof Error ? e.message : "تعذّر فتح بوابة الدفع";
          toast.error(msg);
        }
      } else {
        toast.success("تمّ إرسال الحجز. الدفع عند الاستلام.");
      }
      setQty(""); setPhone(""); setNote(""); setAddress(""); setWilaya("");
      navigate({ to: "/orders" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading || !listing) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex justify-center py-32"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
      </div>
    );
  }

  const avg = reviews && reviews.length > 0
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : null;
  const isOwn = user?.id === listing.seller_id;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto max-w-5xl px-4 py-10">
        <Link to="/listings" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> العودة للسوق
        </Link>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
            {listing.image_url ? (
              <img src={listing.image_url} alt={listing.title} className="aspect-[4/3] w-full object-cover" />
            ) : (
              <div className="flex aspect-[4/3] w-full items-center justify-center bg-gradient-earth">
                <Package className="h-20 w-20 text-muted-foreground/40" />
              </div>
            )}
          </div>

          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-widest text-accent">
              {CATEGORY_LABELS[listing.category] ?? listing.category}
            </span>
            <h1 className="mt-2 font-serif text-4xl leading-tight">{listing.title}</h1>
            <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{listing.region}</span>
              {avg && (
                <span className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-primary text-primary" />
                  {avg} <span className="text-xs">({reviews!.length})</span>
                </span>
              )}
            </div>
            {listing.description && <p className="mt-4 leading-relaxed text-foreground/80">{listing.description}</p>}

            <div className="mt-6 flex items-end justify-between border-y border-border py-4">
              <div>
                <div className="font-serif text-4xl text-primary">
                  {listing.price_dzd > 0 ? `${listing.price_dzd} دج` : "مجاني"}
                </div>
                <div className="text-xs text-muted-foreground">للكمية الكاملة ({listing.quantity_kg} كغ)</div>
              </div>
              {user && !isOwn && (
                <Button variant="outline" size="icon" onClick={() => toggleFav.mutate()} aria-label="مفضّلة">
                  <Heart className={`h-4 w-4 ${fav ? "fill-primary text-primary" : ""}`} />
                </Button>
              )}
            </div>

            {!user && (
              <Button asChild className="mt-6"><Link to="/auth">سجّل الدخول للحجز</Link></Button>
            )}

            {user && !isOwn && listing.status === "available" && (
              <form
                onSubmit={(e) => { e.preventDefault(); reserve.mutate(); }}
                className="mt-6 space-y-3 rounded-xl border border-border bg-card p-5 shadow-soft"
              >
                <h3 className="font-serif text-xl">احجز هذا العرض</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>الكمية (كغ)</Label>
                    <Input type="number" min="1" max={listing.quantity_kg} value={qty} onChange={(e) => setQty(e.target.value)} required />
                  </div>
                  <div>
                    <Label>هاتفك</Label>
                    <Input value={phone} onChange={(e) => setPhone(e.target.value)} required />
                  </div>
                </div>

                <div className="space-y-2 rounded-lg bg-muted/40 p-3">
                  <Label className="text-xs font-medium">طريقة الاستلام</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setDeliveryMethod("pickup")}
                      className={`rounded-md border px-3 py-2 text-sm transition ${deliveryMethod === "pickup" ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"}`}>
                      استلام من البائع
                    </button>
                    <button type="button" onClick={() => setDeliveryMethod("delivery")}
                      className={`rounded-md border px-3 py-2 text-sm transition ${deliveryMethod === "delivery" ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"}`}>
                      توصيل لكل الجزائر
                    </button>
                  </div>

                  {deliveryMethod === "delivery" && (
                    <div className="space-y-2 pt-2">
                      <div>
                        <Label>الولاية</Label>
                        <select
                          value={wilaya}
                          onChange={(e) => setWilaya(e.target.value)}
                          required
                          className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        >
                          <option value="">اختر ولايتك</option>
                          {WILAYAS.map((w) => (
                            <option key={w.code} value={w.code}>{w.code} - {w.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <Label>العنوان التفصيلي</Label>
                        <Textarea value={address} onChange={(e) => setAddress(e.target.value)} rows={2}
                          placeholder="البلدية، الحي، أقرب نقطة معروفة..." required />
                      </div>
                      {wilaya && qty && Number(qty) > 0 && (
                        <div className="flex items-center justify-between rounded-md bg-background p-2 text-sm">
                          <span className="text-muted-foreground">رسوم التوصيل التقديرية</span>
                          <span className="font-medium text-primary">
                            {calcDeliveryFee(wilaya, Number(qty))} دج
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {listing.price_dzd > 0 && (
                  <div className="space-y-2 rounded-lg bg-muted/40 p-3">
                    <Label className="text-xs font-medium">طريقة الدفع</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <button type="button" onClick={() => setPaymentMethod("cod")}
                        className={`flex items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm transition ${paymentMethod === "cod" ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"}`}>
                        <Banknote className="h-4 w-4" /> نقدًا عند الاستلام
                      </button>
                      <button type="button" onClick={() => setPaymentMethod("chargily")}
                        className={`flex items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm transition ${paymentMethod === "chargily" ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"}`}>
                        <CreditCard className="h-4 w-4" /> CIB / Edahabia
                      </button>
                    </div>
                    <p className="text-[11px] text-muted-foreground">
                      {paymentMethod === "chargily"
                        ? "سيتم تحويلك لبوابة الدفع الآمنة Chargily Pay."
                        : "ادفع نقدًا للبائع عند استلام الطلب."}
                    </p>
                  </div>
                )}

                <div>
                  <Label>ملاحظة (اختياري)</Label>
                  <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} />
                </div>
                <Button type="submit" disabled={reserve.isPending} className="w-full">
                  {reserve.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                  تأكيد الحجز
                </Button>
              </form>
            )}

            {isOwn && (
              <p className="mt-6 rounded-xl border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                هذا عرضك. تابع الحجوزات من صفحة الطلبات.
              </p>
            )}
          </div>
        </div>

        <section className="mt-12">
          <h2 className="font-serif text-2xl">آراء المشترين</h2>
          {!reviews || reviews.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">لا توجد تقييمات بعد لهذا البائع.</p>
          ) : (
            <ul className="mt-4 grid gap-3 sm:grid-cols-2">
              {reviews.map((r) => (
                <li key={r.id} className="rounded-xl border border-border bg-card p-4 shadow-soft">
                  <div className="flex items-center gap-1 text-primary">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < r.rating ? "fill-primary" : "opacity-30"}`} />
                    ))}
                  </div>
                  {r.comment && <p className="mt-2 text-sm leading-relaxed">{r.comment}</p>}
                  <p className="mt-2 text-xs text-muted-foreground">
                    {new Date(r.created_at).toLocaleDateString("ar-DZ")}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
