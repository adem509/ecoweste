import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/chargily-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.CHARGILY_SECRET_KEY;
        if (!apiKey) return new Response("not configured", { status: 500 });

        const signature = request.headers.get("signature") || "";
        const raw = await request.text();

        const expected = createHmac("sha256", apiKey).update(raw).digest("hex");
        let ok = false;
        try {
          ok =
            signature.length === expected.length &&
            timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
        } catch {
          ok = false;
        }
        if (!ok) return new Response("invalid signature", { status: 401 });

        let payload: { type?: string; data?: { id?: string; status?: string } };
        try {
          payload = JSON.parse(raw);
        } catch {
          return new Response("bad json", { status: 400 });
        }

        const checkoutId = payload.data?.id;
        if (!checkoutId) return new Response("ok");

        const newStatus =
          payload.type === "checkout.paid" || payload.data?.status === "paid"
            ? "paid"
            : payload.type === "checkout.failed"
              ? "failed"
              : null;

        if (newStatus) {
          await supabaseAdmin
            .from("orders")
            .update({ payment_status: newStatus })
            .eq("payment_ref", checkoutId);
        }

        return new Response("ok");
      },
    },
  },
});
