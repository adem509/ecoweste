import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Leaf, UserPlus, PackagePlus, Handshake, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-compost.jpg";

const steps = [
  {
    icon: UserPlus,
    title: "أنشئ حسابك",
    desc: "سجّل بصفتك صاحب نفايات أو فلاحًا أو مشروع تسميد في دقائق.",
  },
  {
    icon: PackagePlus,
    title: "انشر عرضك",
    desc: "أضف نوع النفايات العضوية، الكمية، والمنطقة مع صورة توضيحية.",
  },
  {
    icon: Handshake,
    title: "تواصل واتّفق",
    desc: "يتواصل المستفيدون معك مباشرةً للاتفاق على السعر والتوقيت.",
  },
  {
    icon: Truck,
    title: "سلّم واستفد",
    desc: "يتم الجمع والنقل، فتتحوّل نفاياتك إلى سماد أو طاقة ومورد ماليّ.",
  },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ECOWASTE — حوّل نفاياتك العضوية إلى مورد" },
      { name: "description", content: "منصة جزائرية تربط أصحاب النفايات العضوية بالفلاحين ومشاريع التسميد." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-gradient-earth p-4 py-10">
      <div className="mx-auto w-full max-w-md text-center">
        <div className="mb-8 flex items-center justify-center gap-2">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-warm text-primary-foreground shadow-soft">
            <Leaf className="h-5 w-5" />
          </span>
          <span className="font-serif text-4xl">ECOWASTE</span>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-elegant">
          <img
            src={heroImage}
            alt="نفايات عضوية"
            className="aspect-[16/9] w-full object-cover"
          />
          <div className="p-8">
            <h1 className="font-serif text-3xl leading-tight md:text-4xl">
              نفايتُك العضويّة
              <br />
              <span className="italic text-primary">مورد لشخص آخر</span>
            </h1>

            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              منصّة تربط أصحاب النفايات العضوية بالفلاحين ومشاريع التسميد.
            </p>

            <div className="mt-6 flex flex-col gap-3">
              <Button asChild size="lg" className="w-full shadow-soft">
                <Link to="/auth">
                  ابدأ الآن
                  <ArrowLeft className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="w-full">
                <Link to="/listings">تصفّح العروض</Link>
              </Button>
            </div>
          </div>
        </div>

        <section className="mt-12 text-right">
          <div className="mb-6 text-center">
            <p className="font-sans text-xs uppercase tracking-[0.2em] text-primary">كيف يعمل ECOWASTE</p>
            <h2 className="mt-2 font-serif text-3xl">أربع خطوات بسيطة</h2>
          </div>
          <ol className="space-y-3">
            {steps.map((step, idx) => (
              <li
                key={step.title}
                className="flex items-start gap-4 rounded-xl border border-border bg-card p-4 shadow-soft"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-warm text-primary-foreground">
                  <step.icon className="h-5 w-5" />
                </span>
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-lg text-primary">{`0${idx + 1}`}</span>
                    <h3 className="font-serif text-lg leading-tight">{step.title}</h3>
                  </div>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <p className="mt-10 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} ECOWASTE
        </p>
      </div>
    </div>
  );
}
