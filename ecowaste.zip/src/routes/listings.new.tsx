import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Camera, ImagePlus, Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/listings/new")({
  head: () => ({ meta: [{ title: "عرض جديد | ECOWASTE" }] }),
  component: NewListingPage,
});

const schema = z.object({
  title: z.string().trim().min(3, "عنوان قصير جدًا").max(120),
  description: z.string().trim().max(800).optional(),
  category: z.enum(["food_scraps", "garden_waste", "market_waste", "animal_manure", "agricultural_residue", "other"]),
  quantity_kg: z.coerce.number().positive("أدخل كمية صالحة"),
  price_dzd: z.coerce.number().min(0),
  region: z.string().trim().min(2, "أدخل المنطقة").max(80),
});

function NewListingPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [user, loading, navigate]);

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "food_scraps" as const,
    quantity_kg: "",
    price_dzd: "0",
    region: "",
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const pickFile = (f: File | null) => {
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("الرجاء اختيار صورة");
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      toast.error("حجم الصورة يجب أن يكون أقل من 5 ميغا");
      return;
    }
    setImageFile(f);
    setImagePreview(URL.createObjectURL(f));
  };

  const clearImage = () => {
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImageFile(null);
    setImagePreview(null);
    if (fileRef.current) fileRef.current.value = "";
    if (camRef.current) camRef.current.value = "";
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "بيانات غير صحيحة");
      return;
    }
    setBusy(true);
    try {
      let image_url: string | null = null;
      if (imageFile) {
        const ext = imageFile.name.split(".").pop()?.toLowerCase() || "jpg";
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("listing-images")
          .upload(path, imageFile, { cacheControl: "3600", upsert: false, contentType: imageFile.type });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("listing-images").getPublicUrl(path);
        image_url = pub.publicUrl;
      }

      const { error } = await supabase.from("listings").insert({
        seller_id: user.id,
        title: parsed.data.title,
        description: parsed.data.description || null,
        category: parsed.data.category,
        quantity_kg: parsed.data.quantity_kg,
        price_dzd: parsed.data.price_dzd,
        region: parsed.data.region,
        image_url,
      });
      if (error) throw error;
      toast.success("تمّ نشر عرضك!");
      navigate({ to: "/dashboard" });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "حدث خطأ غير متوقع";
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto max-w-2xl px-4 py-16">
        <h1 className="mb-2 font-serif text-5xl">عرض جديد</h1>
        <p className="mb-10 text-muted-foreground">أضف تفاصيل النفايات التي تودّ بيعها أو إهداءها.</p>

        <form onSubmit={onSubmit} className="space-y-5 rounded-2xl border border-border bg-card p-8 shadow-soft">
          <div className="space-y-2">
            <Label>صورة المنتج</Label>
            {imagePreview ? (
              <div className="relative overflow-hidden rounded-xl border border-border">
                <img src={imagePreview} alt="معاينة" className="aspect-[4/3] w-full object-cover" />
                <button
                  type="button"
                  onClick={clearImage}
                  className="absolute right-2 top-2 rounded-full bg-background/90 p-1.5 shadow hover:bg-background"
                  aria-label="إزالة الصورة"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => camRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-muted/30 px-4 py-6 text-sm transition hover:border-primary hover:bg-primary/5"
                >
                  <Camera className="h-6 w-6 text-primary" />
                  <span>التقط صورة</span>
                </button>
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-muted/30 px-4 py-6 text-sm transition hover:border-primary hover:bg-primary/5"
                >
                  <ImagePlus className="h-6 w-6 text-primary" />
                  <span>من المعرض</span>
                </button>
              </div>
            )}
            <input
              ref={camRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => pickFile(e.target.files?.[0] ?? null)}
            />
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => pickFile(e.target.files?.[0] ?? null)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">العنوان</Label>
            <Input id="title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="بقايا خضار من مطعم" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="desc">الوصف (اختياري)</Label>
            <Textarea id="desc" rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>الصنف</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as typeof form.category })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="food_scraps">بقايا طعام</SelectItem>
                  <SelectItem value="garden_waste">نفايات حديقة</SelectItem>
                  <SelectItem value="market_waste">نفايات سوق</SelectItem>
                  <SelectItem value="animal_manure">روث حيواني</SelectItem>
                  <SelectItem value="agricultural_residue">مخلفات زراعية</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="region">المنطقة</Label>
              <Input id="region" value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} placeholder="الجزائر العاصمة" required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="qty">الكمية (كغ)</Label>
              <Input id="qty" type="number" min="0.1" step="0.1" value={form.quantity_kg} onChange={(e) => setForm({ ...form, quantity_kg: e.target.value })} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">السعر (دج) — 0 للمجاني</Label>
              <Input id="price" type="number" min="0" step="1" value={form.price_dzd} onChange={(e) => setForm({ ...form, price_dzd: e.target.value })} />
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={busy}>
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            {busy ? "جارٍ النشر..." : "نشر العرض"}
          </Button>
        </form>
      </div>
    </div>
  );
}
