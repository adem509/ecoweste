import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { ListingCard, type Listing } from "@/components/ListingCard";

export const Route = createFileRoute("/favorites")({
  head: () => ({ meta: [{ title: "المفضّلة | ECOWASTE" }] }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => { if (!loading && !user) navigate({ to: "/auth" }); }, [user, loading, navigate]);

  const { data, isLoading } = useQuery({
    queryKey: ["favorites", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("favorites").select("listing_id, listings(*)").eq("user_id", user!.id);
      if (error) throw error;
      return (data ?? []).map((r) => r.listings as unknown as Listing).filter(Boolean);
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from("favorites").delete().eq("user_id", user!.id).eq("listing_id", id);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["favorites"] }),
  });

  if (loading || !user) return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto px-4 py-12">
        <p className="mb-2 text-sm uppercase tracking-widest text-accent">حسابي</p>
        <h1 className="mb-8 font-serif text-4xl">العروض المفضّلة</h1>

        {isLoading && <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin" /></div>}

        {data && data.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border bg-card p-16 text-center text-muted-foreground">
            لم تُضف أي عرض إلى المفضّلة بعد.
          </div>
        )}

        {data && data.length > 0 && (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {data.map((l) => (
              <ListingCard key={l.id} listing={l} isFavorite onToggleFavorite={() => remove.mutate(l.id)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
