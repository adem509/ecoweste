import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { getCommunityItem, communityItems, type CommunityItem } from "@/lib/community-data";

export const Route = createFileRoute("/community/$slug")({
  head: ({ params }) => {
    const item = getCommunityItem(params.slug);
    return {
      meta: [
        { title: item ? `${item.title} | ECOWASTE` : "ECOWASTE" },
        { name: "description", content: item?.intro.slice(0, 160) ?? "" },
      ],
    };
  },
  loader: ({ params }) => {
    const item = getCommunityItem(params.slug);
    if (!item) throw notFound();
    return { item };
  },
  notFoundComponent: () => (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="font-serif text-4xl">المحتوى غير موجود</h1>
        <Button asChild className="mt-6"><Link to="/community">العودة للمجتمع</Link></Button>
      </div>
    </div>
  ),
  errorComponent: ({ reset }) => (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="font-serif text-3xl">حدث خطأ</h1>
        <Button onClick={reset} className="mt-6">إعادة المحاولة</Button>
      </div>
    </div>
  ),
  component: CommunityDetail,
});

function CommunityDetail() {
  const { item } = Route.useLoaderData() as { item: CommunityItem };
  const Icon = item.icon;
  const related = communityItems.filter((i) => i.slug !== item.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="border-b border-border/60 bg-gradient-earth">
        <div className="container mx-auto px-4 py-12">
          <Link to="/community" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowRight className="h-4 w-4" />
            العودة للمجتمع
          </Link>
          <div className="mt-6 grid items-center gap-10 md:grid-cols-2">
            <div>
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-3 py-1 text-xs uppercase tracking-widest text-accent">
                <Icon className="h-4 w-4" />
                {item.kind === "guide" ? "دليل عملي" : "مبادرة مجتمعية"}
              </div>
              <h1 className="font-serif text-4xl md:text-5xl">{item.title}</h1>
              <p className="mt-4 text-muted-foreground leading-relaxed">{item.intro}</p>
              {item.badge && (
                <span className="mt-4 inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  {item.badge}
                </span>
              )}
            </div>
            <div className="overflow-hidden rounded-2xl border border-border shadow-elegant">
              <img src={item.image} alt={item.title} width={1024} height={768} className="aspect-[4/3] w-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Sections */}
      <section className="container mx-auto px-4 py-16">
        <div className="mx-auto max-w-3xl space-y-10">
          {item.sections.map((s, idx) => (
            <article key={idx} className="rounded-2xl border border-border bg-card p-8 shadow-soft">
              <div className="mb-3 flex items-baseline gap-3">
                <span className="font-serif text-2xl text-primary">{`0${idx + 1}`}</span>
                <h2 className="font-serif text-2xl">{s.heading}</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">{s.body}</p>
              {s.bullets && (
                <ul className="mt-4 space-y-2">
                  {s.bullets.map((b, i) => (
                    <li key={i} className="flex gap-3 text-sm text-foreground/90">
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              )}
            </article>
          ))}

          {item.cta && (
            <div className="rounded-3xl border border-border bg-gradient-warm p-10 text-center text-primary-foreground shadow-elegant">
              <h3 className="font-serif text-3xl">جاهز للخطوة التالية؟</h3>
              <Button asChild size="lg" variant="secondary" className="mt-5">
                <Link to={item.cta.to}>
                  {item.cta.label}
                  <ArrowLeft className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Related */}
      <section className="border-t border-border/60 bg-card/40">
        <div className="container mx-auto px-4 py-16">
          <h2 className="mb-8 font-serif text-3xl">اقرأ أيضًا</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {related.map((r) => (
              <Link
                key={r.slug}
                to="/community/$slug"
                params={{ slug: r.slug }}
                className="group overflow-hidden rounded-2xl border border-border bg-background shadow-soft transition hover:-translate-y-1 hover:shadow-elegant"
              >
                <div className="aspect-[4/3] overflow-hidden bg-muted">
                  <img src={r.image} alt={r.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                </div>
                <div className="p-5">
                  <h3 className="font-serif text-xl">{r.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{r.text}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
