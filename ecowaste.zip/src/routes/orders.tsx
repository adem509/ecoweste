import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Star, Truck, Package, CreditCard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { getWilaya } from "@/lib/algeria";
import { createChargilyCheckout } from "@/lib/chargily.functions";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "طلباتي | ECOWASTE" }] }),
  component: OrdersPage,
});

interface Order {
  id: string;
  listing_id: string;
  buyer_id: string;
  seller_id: string;
  quantity_kg: number;
  total_dzd: number;
  status: "pending" | "accepted" | "rejected" | "completed" | "cancelled";
  buyer_phone: string | null;
  buyer_note: string | null;
  delivery_method: string;
  delivery_wilaya: string | null;
  delivery_address: string | null;
  delivery_fee_dzd: number;
  payment_method: string;
  payment_status: string;
  payment_url: string | null;
  created_at: string;
  listings: { title: string; region: string } | null;
}

const STATUS = {
  pending: { label: "قيد الانتظار", cls: "bg-muted text-muted-foreground" },
  accepted: { label: "مقبول", cls: "bg-sage text-sage-foreground" },
  rejected: { label: "مرفوض", cls: "bg-destructive/10 text-destructive" },
  completed: { label: "مكتمل", cls: "bg-primary text-primary-foreground" },
  cancelled: { label: "ملغى", cls: "bg-muted text-muted-foreground" },
};

function OrdersPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => { if (!loading && !user) navigate({ to: "/auth" }); }, [user, loading, navigate]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const p = params.get("payment");
    if (p === "success") {
      toast.success("تمّ الدفع بنجاح ✓");
      qc.invalidateQueries({ queryKey: ["orders-out"] });
      window.history.replaceState({}, "", "/orders");
    } else if (p === "failed") {
      toast.error("فشل الدفع. يمكنك المحاولة مجددًا.");
      window.history.replaceState({}, "", "/orders");
    }
  }, [qc]);

  const incoming = useQuery({
    queryKey: ["orders-in", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders").select("*, listings(title,region)").eq("seller_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Order[];
    },
  });

  const outgoing = useQuery({
    queryKey: ["orders-out", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders").select("*, listings(title,region)").eq("buyer_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Order[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: Order["status"] }) => {
      const { error } = await supabase.from("orders").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تمّ التحديث");
      qc.invalidateQueries({ queryKey: ["orders-in"] });
      qc.invalidateQueries({ queryKey: ["orders-out"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading || !user) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto max-w-4xl px-4 py-12">
        <p className="mb-2 text-sm uppercase tracking-widest text-accent">الحجوزات</p>
        <h1 className="mb-8 font-serif text-4xl">طلباتي</h1>

        <Tabs defaultValue="out">
          <TabsList>
            <TabsTrigger value="out">حجوزاتي ({outgoing.data?.length ?? 0})</TabsTrigger>
            <TabsTrigger value="in">طلبات على عروضي ({incoming.data?.length ?? 0})</TabsTrigger>
          </TabsList>

          <TabsContent value="out" className="mt-6 space-y-3">
            {outgoing.data?.length === 0 && <Empty text="لم تحجز أي عرض بعد." />}
            {outgoing.data?.map((o) => (
              <OrderRow key={o.id} order={o} role="buyer"
                onComplete={() => updateStatus.mutate({ id: o.id, status: "completed" })}
                onCancel={() => updateStatus.mutate({ id: o.id, status: "cancelled" })}
              />
            ))}
          </TabsContent>

          <TabsContent value="in" className="mt-6 space-y-3">
            {incoming.data?.length === 0 && <Empty text="لا توجد طلبات على عروضك حاليًا." />}
            {incoming.data?.map((o) => (
              <OrderRow key={o.id} order={o} role="seller"
                onAccept={() => updateStatus.mutate({ id: o.id, status: "accepted" })}
                onReject={() => updateStatus.mutate({ id: o.id, status: "rejected" })}
                onComplete={() => updateStatus.mutate({ id: o.id, status: "completed" })}
              />
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center text-muted-foreground">
      {text}
    </div>
  );
}

function OrderRow({
  order, role, onAccept, onReject, onComplete, onCancel,
}: {
  order: Order; role: "buyer" | "seller";
  onAccept?: () => void; onReject?: () => void; onComplete?: () => void; onCancel?: () => void;
}) {
  const s = STATUS[order.status];
  return (
    <article className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/listings/$id" params={{ id: order.listing_id }} className="font-serif text-xl hover:text-primary">
            {order.listings?.title ?? "عرض"}
          </Link>
          <p className="text-xs text-muted-foreground">
            {order.listings?.region} · {new Date(order.created_at).toLocaleDateString("ar-DZ")}
          </p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium ${s.cls}`}>{s.label}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
        <Field label="الكمية" value={`${order.quantity_kg} كغ`} />
        <Field label="الإجمالي" value={`${order.total_dzd} دج`} />
        <Field label="الدفع" value={paymentLabel(order)} />
        {order.buyer_phone && role === "seller" && <Field label="هاتف المشتري" value={order.buyer_phone} />}
      </div>

      <div className="mt-3 flex items-start gap-2 rounded-lg border border-border bg-muted/30 p-3 text-sm">
        {order.delivery_method === "delivery" ? (
          <>
            <Truck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <div className="flex-1">
              <p className="font-medium">توصيل إلى {getWilaya(order.delivery_wilaya ?? "")?.name ?? "—"}</p>
              {order.delivery_address && (
                <p className="text-xs text-muted-foreground">{order.delivery_address}</p>
              )}
              <p className="mt-1 text-xs text-muted-foreground">رسوم التوصيل: {order.delivery_fee_dzd} دج</p>
            </div>
          </>
        ) : (
          <>
            <Package className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <p>استلام مباشر من البائع</p>
          </>
        )}
      </div>

      {order.buyer_note && (
        <p className="mt-3 rounded-lg bg-muted/50 p-3 text-sm text-muted-foreground">{order.buyer_note}</p>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        {role === "buyer" && order.payment_method === "chargily" && order.payment_status !== "paid" && order.status !== "cancelled" && order.status !== "rejected" && (
          <PayNowButton orderId={order.id} existingUrl={order.payment_url} />
        )}
        {role === "seller" && order.status === "pending" && (
          <>
            <Button size="sm" onClick={onAccept}>قبول</Button>
            <Button size="sm" variant="outline" onClick={onReject}>رفض</Button>
          </>
        )}
        {role === "seller" && order.status === "accepted" && (
          <Button size="sm" onClick={onComplete}>تمّ التسليم</Button>
        )}
        {role === "buyer" && order.status === "pending" && (
          <Button size="sm" variant="outline" onClick={onCancel}>إلغاء الحجز</Button>
        )}
        {role === "buyer" && order.status === "accepted" && (
          <Button size="sm" onClick={onComplete}>تأكيد الاستلام</Button>
        )}
        {role === "buyer" && order.status === "completed" && (
          <ReviewForm orderId={order.id} sellerId={order.seller_id} />
        )}
      </div>
    </article>
  );
}

function paymentLabel(o: Order): string {
  if (o.payment_method === "chargily") {
    if (o.payment_status === "paid") return "مدفوع ✓";
    if (o.payment_status === "failed") return "فشل الدفع";
    return "بانتظار الدفع";
  }
  return "عند الاستلام";
}

function PayNowButton({ orderId, existingUrl }: { orderId: string; existingUrl: string | null }) {
  const chargilyCheckout = useServerFn(createChargilyCheckout);
  const [busy, setBusy] = useState(false);
  const onClick = async () => {
    if (existingUrl) {
      window.location.href = existingUrl;
      return;
    }
    setBusy(true);
    try {
      const { checkout_url } = await chargilyCheckout({ data: { order_id: orderId } });
      window.location.href = checkout_url;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "تعذّر فتح بوابة الدفع";
      toast.error(msg);
      setBusy(false);
    }
  };
  return (
    <Button size="sm" onClick={onClick} disabled={busy}>
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
      ادفع الآن
    </Button>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

function ReviewForm({ orderId, sellerId }: { orderId: string; sellerId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [open, setOpen] = useState(false);

  const { data: existing } = useQuery({
    queryKey: ["my-review", orderId],
    queryFn: async () => {
      const { data } = await supabase.from("reviews").select("id").eq("order_id", orderId).maybeSingle();
      return !!data;
    },
  });

  const submit = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("auth");
      if (rating < 1) throw new Error("اختر تقييماً");
      const { error } = await supabase.from("reviews").insert({
        order_id: orderId, reviewer_id: user.id, seller_id: sellerId,
        rating, comment: comment.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("شكرًا على تقييمك");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["my-review", orderId] });
      qc.invalidateQueries({ queryKey: ["reviews"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (existing) return <span className="text-xs text-muted-foreground">تمّ التقييم ✓</span>;

  if (!open) return <Button size="sm" variant="outline" onClick={() => setOpen(true)}>قيّم البائع</Button>;

  return (
    <div className="w-full space-y-2 rounded-lg border border-border p-3">
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" onClick={() => setRating(n)} aria-label={`${n} نجوم`}>
            <Star className={`h-6 w-6 ${n <= rating ? "fill-primary text-primary" : "text-muted-foreground"}`} />
          </button>
        ))}
      </div>
      <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="تعليق (اختياري)" rows={2} />
      <div className="flex gap-2">
        <Button size="sm" onClick={() => submit.mutate()} disabled={submit.isPending}>إرسال</Button>
        <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
      </div>
    </div>
  );
}
