import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/lib/auth-context";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-7xl text-primary">٤٠٤</h1>
        <h2 className="mt-4 font-serif text-2xl">الصفحة غير موجودة</h2>
        <p className="mt-2 text-sm text-muted-foreground">يبدو أنّ هذا الرابط لم يعد متاحًا.</p>
        <Link to="/" className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
          العودة إلى الرئيسية
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-2xl">حدث خطأ ما</h1>
        <p className="mt-2 text-sm text-muted-foreground">حاول إعادة تحميل الصفحة.</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          إعادة المحاولة
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ECOWASTE — سوق بيع النفايات العضوية" },
      { name: "description", content: "منصة تربط أصحاب النفايات العضوية بالفلاحين ومشاريع التسميد لتحويل المخلّفات إلى مورد." },
      { property: "og:title", content: "ECOWASTE — سوق بيع النفايات العضوية" },
      { name: "twitter:title", content: "ECOWASTE — سوق بيع النفايات العضوية" },
      { property: "og:description", content: "منصة تربط أصحاب النفايات العضوية بالفلاحين ومشاريع التسميد لتحويل المخلّفات إلى مورد." },
      { name: "twitter:description", content: "منصة تربط أصحاب النفايات العضوية بالفلاحين ومشاريع التسميد لتحويل المخلّفات إلى مورد." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/65cab063-b499-4e7b-a4f9-b350c6fa5540/id-preview-636b0d30--c1d36677-ae0f-437e-a719-1bc36f759716.lovable.app-1779887336824.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/65cab063-b499-4e7b-a4f9-b350c6fa5540/id-preview-636b0d30--c1d36677-ae0f-437e-a719-1bc36f759716.lovable.app-1779887336824.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Outlet />
        <Toaster position="top-center" richColors />
      </AuthProvider>
    </QueryClientProvider>
  );
}
