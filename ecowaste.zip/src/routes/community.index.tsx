import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { communityItems } from "@/lib/community-data";

export const Route = createFileRoute("/community/")({
  head: () => ({
    meta: [
      { title: "المجتمع | ECOWASTE" },
      { name: "description", content: "أدلة تعليمية ومبادرات مجتمعية ونقاط جمع وتبرعات لتحويل النفايات العضوية إلى خير." },
    ],
  }),
  component: CommunityPage,
});

function CommunityPage() {
  const guides = communityItems.filter((i) => i.kind === "guide");
  const initiatives = communityItems.filter((i) => i.kind === "initiative");

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <section className="border-b border-border/60 bg-gradient-earth">
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="mb-3 text-sm uppercase tracking-widest text-accent">المجتمع</p>
          <h1 className="mx-auto max-w-3xl font-serif text-5xl md:text-6xl">ECOWASTE يبدأ من الحيّ</h1>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            أدلة تعليمية، مبادرات مجتمعية، ونقاط جمع تربط بين العائلات والفلاحين والجمعيات.
          </p>
        </div>
      </section>

      {/* Educational guides */}
      <section className="container mx-auto px-4 py-20">
        <div className="mb-10">
          <p className="mb-2 text-sm uppercase tracking-widest text-accent">تعلّم</p>
          <h2 className="font-serif text-4xl">أدلة عملية</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {guides.map((g) => (
            <Link
              key={g.slug}
              to="/community/$slug"
              params={{ slug: g.slug }}
              className="group overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <div className="aspect-[4/3] overflow-hidden bg-muted">
                <img src={g.image} alt={g.title} loading="lazy" width={1024} height={768} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="p-6">
                <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <g.icon className="h-5 w-5" />
                </div>
                <h3 className="font-serif text-2xl">{g.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{g.text}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                  اقرأ الدليل
                  <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Initiatives */}
      <section className="border-t border-border/60 bg-card/40">
        <div className="container mx-auto px-4 py-20">
          <div className="mb-10">
            <p className="mb-2 text-sm uppercase tracking-widest text-accent">مبادرات</p>
            <h2 className="font-serif text-4xl">من أجل بيئة أنظف</h2>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {initiatives.map((i) => (
              <Link
                key={i.slug}
                to="/community/$slug"
                params={{ slug: i.slug }}
                className="group overflow-hidden rounded-2xl border border-border bg-background shadow-soft transition hover:-translate-y-1 hover:shadow-elegant"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-muted">
                  <img src={i.image} alt={i.title} loading="lazy" width={1024} height={768} className="h-full w-full object-cover" />
                  {i.badge && (
                    <span className="absolute top-3 start-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium backdrop-blur">
                      {i.badge}
                    </span>
                  )}
                </div>
                <div className="p-6">
                  <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-full bg-sage/30 text-primary">
                    <i.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-2xl">{i.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{i.text}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                    اكتشف المبادرة
                    <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-20">
        <div className="rounded-3xl border border-border bg-gradient-warm p-10 text-center text-primary-foreground shadow-elegant md:p-16">
          <h2 className="font-serif text-4xl md:text-5xl">شارك في صناعة الخير</h2>
          <p className="mx-auto mt-3 max-w-xl opacity-90">
            انشر عرضك أو تبرّع بنفاياتك العضوية اليوم. كل كيلوغرام يُعاد تدويره = خطوة نحو مستقبل أنظف.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" variant="secondary">
              <Link to="/listings/new">انشر عرضًا</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="bg-background/10 text-primary-foreground hover:bg-background/20">
              <Link to="/listings">تصفّح السوق</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
