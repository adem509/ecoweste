import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2, Plus, Loader2, Recycle, Leaf, Coins } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { ListingCard, type Listing } from "@/components/ListingCard";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "لوحتي | ECOWASTE" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [user, loading, navigate]);

  const { data: listings, isLoading } = useQuery({
    queryKey: ["my-listings", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("listings").select("*").eq("seller_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Listing[];
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["env-stats", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [sold, bought] = await Promise.all([
        supabase.from("orders").select("quantity_kg,total_dzd").eq("seller_id", user!.id).eq("status", "completed"),
        supabase.from("orders").select("quantity_kg").eq("buyer_id", user!.id).eq("status", "completed"),
      ]);
      const soldKg = (sold.data ?? []).reduce((s, o) => s + Number(o.quantity_kg), 0);
      const boughtKg = (bought.data ?? []).reduce((s, o) => s + Number(o.quantity_kg), 0);
      const revenue = (sold.data ?? []).reduce((s, o) => s + Number(o.total_dzd), 0);
      const totalKg = soldKg + boughtKg;
      // ~0.5 kg CO2 saved per kg organic waste diverted from landfill
      const co2 = Math.round(totalKg * 0.5);
      return { totalKg, co2, revenue };
    },
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("listings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تمّ حذف العرض");
      qc.invalidateQueries({ queryKey: ["my-listings"] });
      qc.invalidateQueries({ queryKey: ["listings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto px-4 py-16">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-2 text-sm uppercase tracking-widest text-accent">حسابي</p>
            <h1 className="font-serif text-5xl">عروضي</h1>
          </div>
          <Button asChild size="lg">
            <Link to="/listings/new"><Plus className="h-4 w-4" /> عرض جديد</Link>
          </Button>
        </div>

        <div className="mb-10 grid gap-4 sm:grid-cols-3">
          <StatCard icon={<Recycle className="h-5 w-5" />} label="نفايات تمّ تدويرها" value={`${stats?.totalKg ?? 0} كغ`} />
          <StatCard icon={<Leaf className="h-5 w-5" />} label="انبعاثات CO₂ موفّرة" value={`${stats?.co2 ?? 0} كغ`} />
          <StatCard icon={<Coins className="h-5 w-5" />} label="إيرادات من المبيعات" value={`${stats?.revenue ?? 0} دج`} />
        </div>


        {isLoading && (
          <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
        )}

        {listings && listings.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border bg-card p-16 text-center">
            <h3 className="font-serif text-2xl">لم تنشر أيّ عرض بعد</h3>
            <p className="mt-2 text-muted-foreground">ابدأ بإضافة عرضك الأوّل.</p>
            <Button asChild className="mt-6"><Link to="/listings/new">أضف عرضًا</Link></Button>
          </div>
        )}

        {listings && listings.length > 0 && (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {listings.map((l) => (
              <div key={l.id} className="relative">
                <ListingCard listing={l} />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute bottom-4 start-4 h-9 w-9 rounded-full shadow-elegant"
                  onClick={() => {
                    if (confirm("حذف هذا العرض؟")) deleteMut.mutate(l.id);
                  }}
                  aria-label="حذف"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="flex items-center gap-2 text-primary">{icon}<span className="text-xs uppercase tracking-widest">{label}</span></div>
      <p className="mt-2 font-serif text-3xl">{value}</p>
    </div>
  );
}

