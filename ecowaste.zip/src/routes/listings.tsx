import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { SiteHeader } from "@/components/SiteHeader";
import { ListingCard, CATEGORY_LABELS, type Listing } from "@/components/ListingCard";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";

export const Route = createFileRoute("/listings")({
  head: () => ({
    meta: [
      { title: "السوق | ECOWASTE" },
      { name: "description", content: "تصفّح عروض النفايات العضوية المتاحة حسب المنطقة والصنف." },
    ],
  }),
  component: ListingsPage,
});

function ListingsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [region, setRegion] = useState("");

  const { data, isLoading, error } = useQuery({
    queryKey: ["listings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("listings").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as Listing[];
    },
  });

  const { data: favIds } = useQuery({
    queryKey: ["fav-ids", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("favorites").select("listing_id").eq("user_id", user!.id);
      return new Set((data ?? []).map((r) => r.listing_id as string));
    },
  });

  const toggleFav = useMutation({
    mutationFn: async (listingId: string) => {
      if (!user) return;
      if (favIds?.has(listingId)) {
        await supabase.from("favorites").delete().eq("user_id", user.id).eq("listing_id", listingId);
      } else {
        await supabase.from("favorites").insert({ user_id: user.id, listing_id: listingId });
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["fav-ids"] }),
  });

  const filtered = useMemo(() => {
    if (!data) return [];
    return data.filter((l) => {
      if (cat !== "all" && l.category !== cat) return false;
      if (region && !l.region.includes(region)) return false;
      if (q && !`${l.title} ${l.description ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
  }, [data, q, cat, region]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8 max-w-2xl">
          <p className="mb-2 text-sm uppercase tracking-widest text-accent">السوق</p>
          <h1 className="font-serif text-5xl md:text-6xl">العروض المتاحة</h1>
          <p className="mt-3 text-muted-foreground">حوّل نفاية إلى مورد. اختر ما يناسبك واحجزه.</p>
        </div>

        <div className="mb-8 flex flex-wrap gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft">
          <div className="relative min-w-[200px] flex-1">
            <Search className="pointer-events-none absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن عرض..." className="ps-3 pe-9" />
          </div>
          <Input value={region} onChange={(e) => setRegion(e.target.value)} placeholder="المنطقة" className="w-40" />
          <select
            value={cat}
            onChange={(e) => setCat(e.target.value)}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="all">كل الفئات</option>
            {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>

        {isLoading && <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>}
        {error && <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-6 text-destructive">تعذّر تحميل العروض.</div>}

        {filtered.length === 0 && data && (
          <div className="rounded-2xl border border-dashed border-border bg-card p-16 text-center">
            <h3 className="font-serif text-2xl">لا توجد عروض مطابقة</h3>
            <p className="mt-2 text-muted-foreground">جرّب تعديل البحث أو التصفية.</p>
          </div>
        )}

        {filtered.length > 0 && (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((l) => (
              <ListingCard
                key={l.id}
                listing={l}
                isFavorite={favIds?.has(l.id)}
                onToggleFavorite={user ? () => toggleFav.mutate(l.id) : undefined}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
