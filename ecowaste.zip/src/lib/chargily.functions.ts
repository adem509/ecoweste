import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const CHARGILY_API = "https://pay.chargily.net/api/v2";

export const createChargilyCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      order_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const apiKey = process.env.CHARGILY_SECRET_KEY;
    if (!apiKey) throw new Error("CHARGILY_SECRET_KEY غير معرّف");

    // Fetch the order — RLS ensures buyer can read it
    const { data: order, error } = await supabase
      .from("orders")
      .select("id, buyer_id, total_dzd, payment_status, listing_id")
      .eq("id", data.order_id)
      .single();
    if (error || !order) throw new Error("الطلب غير موجود");
    if (order.buyer_id !== userId) throw new Error("غير مصرّح");
    if (order.payment_status === "paid") throw new Error("الطلب مدفوع مسبقًا");

    const origin = process.env.SITE_URL || "https://organic-link-up.lovable.app";

    const res = await fetch(`${CHARGILY_API}/checkouts`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: Math.round(Number(order.total_dzd)),
        currency: "dzd",
        success_url: `${origin}/orders?payment=success`,
        failure_url: `${origin}/orders?payment=failed`,
        webhook_endpoint: `${origin}/api/public/chargily-webhook`,
        description: `طلب رقم ${order.id.slice(0, 8)}`,
        metadata: [
          { order_id: order.id },
          { buyer_id: order.buyer_id },
        ],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`فشل إنشاء الدفع: ${text}`);
    }
    const checkout = await res.json() as { id: string; checkout_url: string };

    // Save reference + URL on the order (buyer can update via RLS)
    await supabase
      .from("orders")
      .update({
        payment_method: "chargily",
        payment_ref: checkout.id,
        payment_url: checkout.checkout_url,
      })
      .eq("id", order.id);

    return { checkout_url: checkout.checkout_url };
  });
