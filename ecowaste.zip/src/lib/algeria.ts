// 58 ولايات الجزائر مع رسوم شحن تقديرية للنفايات العضوية بالدينار الجزائري
// الرسوم تعتمد على المنطقة الجغرافية (شمال/هضاب/جنوب/أقصى الجنوب)

export interface Wilaya {
  code: string;
  name: string;
  zone: 1 | 2 | 3 | 4; // 1=شمال, 2=هضاب, 3=جنوب, 4=أقصى الجنوب
}

export const WILAYAS: Wilaya[] = [
  { code: "01", name: "أدرار", zone: 4 },
  { code: "02", name: "الشلف", zone: 1 },
  { code: "03", name: "الأغواط", zone: 3 },
  { code: "04", name: "أم البواقي", zone: 2 },
  { code: "05", name: "باتنة", zone: 2 },
  { code: "06", name: "بجاية", zone: 1 },
  { code: "07", name: "بسكرة", zone: 3 },
  { code: "08", name: "بشار", zone: 4 },
  { code: "09", name: "البليدة", zone: 1 },
  { code: "10", name: "البويرة", zone: 1 },
  { code: "11", name: "تمنراست", zone: 4 },
  { code: "12", name: "تبسة", zone: 2 },
  { code: "13", name: "تلمسان", zone: 1 },
  { code: "14", name: "تيارت", zone: 2 },
  { code: "15", name: "تيزي وزو", zone: 1 },
  { code: "16", name: "الجزائر", zone: 1 },
  { code: "17", name: "الجلفة", zone: 2 },
  { code: "18", name: "جيجل", zone: 1 },
  { code: "19", name: "سطيف", zone: 1 },
  { code: "20", name: "سعيدة", zone: 2 },
  { code: "21", name: "سكيكدة", zone: 1 },
  { code: "22", name: "سيدي بلعباس", zone: 1 },
  { code: "23", name: "عنابة", zone: 1 },
  { code: "24", name: "قالمة", zone: 1 },
  { code: "25", name: "قسنطينة", zone: 1 },
  { code: "26", name: "المدية", zone: 1 },
  { code: "27", name: "مستغانم", zone: 1 },
  { code: "28", name: "المسيلة", zone: 2 },
  { code: "29", name: "معسكر", zone: 1 },
  { code: "30", name: "ورقلة", zone: 3 },
  { code: "31", name: "وهران", zone: 1 },
  { code: "32", name: "البيض", zone: 3 },
  { code: "33", name: "إليزي", zone: 4 },
  { code: "34", name: "برج بوعريريج", zone: 1 },
  { code: "35", name: "بومرداس", zone: 1 },
  { code: "36", name: "الطارف", zone: 1 },
  { code: "37", name: "تندوف", zone: 4 },
  { code: "38", name: "تيسمسيلت", zone: 2 },
  { code: "39", name: "الوادي", zone: 3 },
  { code: "40", name: "خنشلة", zone: 2 },
  { code: "41", name: "سوق أهراس", zone: 2 },
  { code: "42", name: "تيبازة", zone: 1 },
  { code: "43", name: "ميلة", zone: 1 },
  { code: "44", name: "عين الدفلى", zone: 1 },
  { code: "45", name: "النعامة", zone: 3 },
  { code: "46", name: "عين تموشنت", zone: 1 },
  { code: "47", name: "غرداية", zone: 3 },
  { code: "48", name: "غليزان", zone: 1 },
  { code: "49", name: "تيميمون", zone: 4 },
  { code: "50", name: "برج باجي مختار", zone: 4 },
  { code: "51", name: "أولاد جلال", zone: 3 },
  { code: "52", name: "بني عباس", zone: 4 },
  { code: "53", name: "عين صالح", zone: 4 },
  { code: "54", name: "عين قزام", zone: 4 },
  { code: "55", name: "تقرت", zone: 3 },
  { code: "56", name: "جانت", zone: 4 },
  { code: "57", name: "المغير", zone: 3 },
  { code: "58", name: "المنيعة", zone: 3 },
];

// رسوم الشحن الأساسية لكل 10 كغ حسب المنطقة
const ZONE_BASE_FEE: Record<number, number> = {
  1: 400,  // شمال
  2: 600,  // هضاب
  3: 900,  // جنوب
  4: 1400, // أقصى الجنوب
};

export function calcDeliveryFee(wilayaCode: string, quantityKg: number): number {
  const w = WILAYAS.find((x) => x.code === wilayaCode);
  if (!w) return 0;
  const base = ZONE_BASE_FEE[w.zone];
  const units = Math.max(1, Math.ceil(quantityKg / 10));
  return base * units;
}

export function getWilaya(code: string): Wilaya | undefined {
  return WILAYAS.find((w) => w.code === code);
}
