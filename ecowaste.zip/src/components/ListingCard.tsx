import { Link } from "@tanstack/react-router";
import { MapPin, Package, Heart, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const CATEGORY_LABELS: Record<string, string> = {
  food_scraps: "بقايا طعام",
  garden_waste: "نفايات حديقة",
  market_waste: "نفايات سوق",
  animal_manure: "روث حيواني",
  agricultural_residue: "مخلفات زراعية",
  other: "أخرى",
};

const STATUS_LABELS: Record<string, string> = {
  available: "متوفّر",
  reserved: "محجوز",
  sold: "تم البيع",
};

export interface Listing {
  id: string;
  title: string;
  description: string | null;
  category: string;
  quantity_kg: number;
  price_dzd: number;
  region: string;
  status: string;
  image_url: string | null;
  created_at: string;
}

export function ListingCard({
  listing,
  isFavorite,
  onToggleFavorite,
}: {
  listing: Listing;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
}) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-shadow hover:shadow-elegant">
      <Link
        to="/listings/$id"
        params={{ id: listing.id }}
        aria-label={listing.title}
        className="flex h-full flex-col"
      >
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          {listing.image_url ? (
            <img
              src={listing.image_url}
              alt={listing.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-earth">
              <Package className="h-12 w-12 text-muted-foreground/40" />
            </div>
          )}
          <span className="absolute top-3 start-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium backdrop-blur">
            {CATEGORY_LABELS[listing.category] ?? listing.category}
          </span>
          <span className={`absolute top-3 end-3 rounded-full px-3 py-1 text-xs font-medium backdrop-blur ${
            listing.status === "available" ? "bg-sage text-sage-foreground" : "bg-muted text-muted-foreground"
          }`}>
            {STATUS_LABELS[listing.status] ?? listing.status}
          </span>
        </div>

        <div className="flex flex-1 flex-col gap-3 p-5">
          <h3 className="font-serif text-2xl leading-tight">{listing.title}</h3>
          {listing.description && (
            <p className="line-clamp-2 text-sm text-muted-foreground">{listing.description}</p>
          )}

          <div className="mt-auto flex items-center justify-between border-t border-border/60 pt-4">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span>{listing.region}</span>
            </div>
            <div className="text-end">
              <div className="font-serif text-2xl text-primary">
                {listing.price_dzd > 0 ? `${listing.price_dzd} دج` : "مجاني"}
              </div>
              <div className="text-xs text-muted-foreground">{listing.quantity_kg} كغ</div>
            </div>
          </div>

          <div className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-colors group-hover:bg-primary/90">
            عرض التفاصيل والطلب
            <ArrowLeft className="h-4 w-4" />
          </div>
        </div>
      </Link>

      {onToggleFavorite && (
        <Button
          variant="ghost"
          size="icon"
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onToggleFavorite(); }}
          aria-label="مفضّلة"
          className="absolute bottom-3 start-3 z-20 h-9 w-9 rounded-full bg-background/90 backdrop-blur hover:bg-background"
        >
          <Heart className={`h-4 w-4 ${isFavorite ? "fill-primary text-primary" : "text-muted-foreground"}`} />
        </Button>
      )}
    </article>
  );
}

export { CATEGORY_LABELS };
