import { Link } from "@tanstack/react-router";
import { Leaf, LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  const { user, signOut } = useAuth();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-warm text-primary-foreground shadow-soft">
            <Leaf className="h-4 w-4" />
          </span>
          <span className="font-serif text-2xl tracking-tight">ECOWASTE</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm md:flex">
          <Link to="/" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
            الرئيسية
          </Link>
          <Link to="/listings" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
            السوق
          </Link>
          <Link to="/community" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
            المجتمع
          </Link>
          {user && (
            <>
              <Link to="/orders" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
                طلباتي
              </Link>
              <Link to="/favorites" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
                المفضّلة
              </Link>
              <Link to="/dashboard" className="text-foreground/70 transition-colors hover:text-foreground" activeProps={{ className: "text-foreground" }}>
                لوحتي
              </Link>
            </>
          )}
        </nav>

        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Button asChild variant="default" size="sm">
                <Link to="/listings/new">عرض جديد</Link>
              </Button>
              <Button variant="ghost" size="icon" onClick={signOut} aria-label="تسجيل الخروج">
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button asChild size="sm">
              <Link to="/auth">دخول</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
